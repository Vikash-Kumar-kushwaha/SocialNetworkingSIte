					
<?php
include('includes/database.php');


							$email=$_POST['email'];
							$password=$_POST['password'];
						{
							echo "welcome".$email.$password;

							$q ="SELECT * FROM user WHERE email = '$email' and password='$password'";
							$result=mysqli_query($conn,$q);
							
							$row = mysqli_fetch_array($result);
							$count = mysqli_num_rows($result);				
								if ($count == 0) 
									{
										
									echo "<script>alert('Please check your username and password!'); window.location='login.php'</script>";
									} 
								else if ($count > 0)
									{
										
										session_start();
										$_SESSION['id'] = $row['user_id'];
										header("location:home.php");
									}
						}				
						
?>